bind = "0.0.0.0:8000"
workers = 4
timeout = 120
accesslog = "logs/access.log"
errorlog = "logs/error.log"
capture_output = True
daemon = True 